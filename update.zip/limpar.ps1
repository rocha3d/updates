# Apaga arquivos específicos se eles existirem

if (Test-Path "lixo.txt") { Remove-Item "lixo.txt" -Force }
if (Test-Path "lixo") { Remove-Item "lixo" -Recurse -Force }

# Remove o próprio script de limpeza para não acumular lixo na pasta
Remove-Item $MyInvocation.MyCommand.Source -Force
